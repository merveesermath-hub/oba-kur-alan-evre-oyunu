# Oba Kur

5. sınıf matematik için hazırlanmış, Yörük kültürü temalı alan–çevre oyunu (MAT.5.4.3). Oyuncu, Ulaş ve ailesine yaylada obalarını kurmaya yardım eder: çitleri ızgaraya kendi yerleştirir, tabloları inceler ve alan ile çevre arasındaki ilişkiyi keşfeder.

## Oyunun akışı
1. **Oba yeri:** 20 birim çitle 5 farklı dikdörtgen kurulur (alanlar 9, 16, 21, 24, 25 birimkare). Alanı 20 birimkareden büyük yerler işaretlenir, en geniş yer sorusu yanıtlanır.
2. **At otlağı:** Alanı 24 birimkare olan 3 farklı otlak kurulur (çit 28, 22, 20 birim), atlar otlağa girer. Ardından 1×24 hesap sorusu, en az çitli ve en uzun otlak seçimi ve iki bölümün karşılaştırması gelir.

Çit koymak için bir noktadan başka bir noktaya sürükleyin, silmek için çite dokunun.

## Dosyalar
- `index.html` : Oyunun tamamı. Görseller, stiller ve kod bu tek dosyanın içindedir, başka dosya gerekmez.
- `README.md` : Bu açıklama.
- `.nojekyll` : GitHub Pages için boş dosya (isteğe bağlı).

## GitHub'a yükleme (klasör yüklemek gerekmez)
1. GitHub'da yeni bir depo oluşturun.
2. **Add file → Upload files** deyin ve zip'ten çıkardığınız dosyaları (en azından `index.html`) sürükleyin ya da seçin. **Commit changes** ile kaydedin.
3. **Settings → Pages** bölümünde **Source: Deploy from a branch**, **Branch: main**, **/ (root)** seçip kaydedin.
4. Birkaç dakika sonra oyun `https://KULLANICI-ADI.github.io/DEPO-ADI/` adresinde açılır.

`index.html` dosyası depo kök dizininde olmalıdır, bir klasörün içinde olmamalıdır.

## Yerelde deneme
`index.html` dosyasına çift tıklayıp tarayıcıda açmanız yeterlidir.

## Notlar
- **Ses:** Müzik ve efektler tarayıcıda üretilir, ses dosyası yoktur. Sesler ilk dokunuştan sonra başlar, sağ üstteki düğmeyle kapatılır.
- **Görseller:** Yapay zekâ ile üretilmiştir. Yayınlamadan önce kullandığınız aracın kullanım koşullarını kontrol edin.
- **Kültürel içerik:** Oba Defteri kartları yayından önce bir halk kültürü uzmanına doğrulatılmalıdır.
- **Lisans:** Bu pakette lisans dosyası yoktur, paylaşım koşullarınıza göre ekleyin.
- **Hazırlanıyor:** Yonca ve Anne ile kilim motifleri bölümü.
